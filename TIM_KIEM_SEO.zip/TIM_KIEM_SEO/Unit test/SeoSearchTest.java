public class SeoSearchTest {

    // Giả lập chức năng tìm kiếm SEO
    public static boolean seoSearch(String query, String[] data) {
        for (String item : data) {
            if (item.toLowerCase().contains(query.toLowerCase())) {
                return true; // Tìm thấy
            }
        }
        return false; // Không tìm thấy
    }

    public static void main(String[] args) {
        // Dữ liệu mẫu
        String[] database = {
            "apple iphone",
            "samsung galaxy",
            "xiaomi redmi",
            "seo optimization guide"
        };

        // Test case 1
        boolean result1 = seoSearch("iphone", database);
        if (result1) {
            System.out.println("Test case 1: PASSED");
        } else {
            System.out.println("Test case 1: FAILED");
        }

        // Test case 2
        boolean result2 = seoSearch("SEO", database);
        if (result2) {
            System.out.println("Test case 2: PASSED");
        } else {
            System.out.println("Test case 2: FAILED");
        }

        // Test case 3
        boolean result3 = seoSearch("nokia", database);
        if (result3) {
            System.out.println("Test case 3: PASSED");
        } else {
            System.out.println("Test case 3: FAILED");
        }
    }
}
