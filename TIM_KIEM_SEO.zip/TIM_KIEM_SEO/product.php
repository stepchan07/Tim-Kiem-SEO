<?php
require_once 'config.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$productID = $_GET['id'] ?? 0;

// Get product details
$stmt = $pdo->prepare("SELECT p.*, c.CategoryName FROM Product p 
                       LEFT JOIN Category c ON p.CategoryID = c.CategoryID 
                       WHERE p.ProductID = ?");
$stmt->execute([$productID]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: index.php');
    exit;
}

// Get related products (same category)
$stmt = $pdo->prepare("SELECT p.*, c.CategoryName FROM Product p 
                       LEFT JOIN Category c ON p.CategoryID = c.CategoryID 
                       WHERE p.CategoryID = ? AND p.ProductID != ?
                       ORDER BY p.Rating DESC LIMIT 4");
$stmt->execute([$product['CategoryID'], $productID]);
$relatedProducts = $stmt->fetchAll();

// Log view (optional)
$stmt = $pdo->prepare("INSERT INTO SearchLog (UserID, Keyword) VALUES (?, ?)");
$stmt->execute([$_SESSION['user_id'], 'View: ' . $product['ProductName']]);
?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($product['ProductName']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        .product-image {
            max-height: 500px;
            object-fit: contain;
            width: 100%;
        }

        .rating-stars {
            color: #ffc107;
        }

        .spec-table th {
            width: 150px;
            background-color: #f8f9fa;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-arrow-left"></i> Quay lại
            </a>
            <div class="d-flex align-items-center text-white">
                <span class="me-3">Xin chào, <?= getCurrentUser() ?></span>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Trang chủ</a></li>
                <li class="breadcrumb-item"><a
                        href="index.php?category=<?= $product['CategoryID'] ?>"><?= htmlspecialchars($product['CategoryName']) ?></a>
                </li>
                <li class="breadcrumb-item active"><?= htmlspecialchars($product['ProductName']) ?></li>
            </ol>
        </nav>

        <!-- Product Details -->
        <div class="row">
            <!-- Product Image -->
            <div class="col-md-5">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <img src="<?= $product['Image'] ? 'uploads/' . $product['Image'] : 'https://via.placeholder.com/500x400?text=No+Image' ?>"
                            class="product-image rounded" alt="<?= htmlspecialchars($product['ProductName']) ?>">
                    </div>
                </div>
            </div>

            <!-- Product Info -->
            <div class="col-md-7">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h2 class="mb-3"><?= htmlspecialchars($product['ProductName']) ?></h2>

                        <!-- Category Badge -->
                        <p class="mb-3">
                            <span class="badge bg-primary fs-6">
                                <i class="bi bi-tag-fill"></i> <?= htmlspecialchars($product['CategoryName']) ?>
                            </span>
                        </p>

                        <!-- Rating -->
                        <div class="mb-3 d-flex align-items-center">
                            <div class="rating-stars fs-5 me-2">
                                <?php
                                $rating = $product['Rating'];
                                for ($i = 1; $i <= 5; $i++) {
                                    if ($i <= floor($rating)) {
                                        echo '<i class="bi bi-star-fill"></i>';
                                    } elseif ($i <= ceil($rating) && $rating - floor($rating) >= 0.5) {
                                        echo '<i class="bi bi-star-half"></i>';
                                    } else {
                                        echo '<i class="bi bi-star"></i>';
                                    }
                                }
                                ?>
                            </div>
                            <span class="fw-bold text-warning"><?= $rating ?></span>
                            <span class="text-muted ms-2">(Đánh giá)</span>
                        </div>

                        <!-- Price -->
                        <div class="mb-4">
                            <h3 class="text-danger mb-0"><?= number_format($product['Price']) ?> đ</h3>
                            <small class="text-muted">Giá đã bao gồm VAT</small>
                        </div>

                        <!-- Description -->
                        <div class="mb-4">
                            <h5 class="border-bottom pb-2">Mô tả sản phẩm</h5>
                            <p class="text-muted">
                                <?= nl2br(htmlspecialchars($product['Description'] ?: 'Chưa có mô tả chi tiết')) ?>
                            </p>
                        </div>

                        <!-- Specifications Table -->
                        <div class="mb-4">
                            <h5 class="border-bottom pb-2">Thông số kỹ thuật</h5>
                            <table class="table table-bordered spec-table">
                                <tbody>
                                    <tr>
                                        <th><i class="bi bi-upc"></i> Mã sản phẩm</th>
                                        <td>SP<?= str_pad($product['ProductID'], 6, '0', STR_PAD_LEFT) ?></td>
                                    </tr>
                                    <tr>
                                        <th><i class="bi bi-list"></i> Danh mục</th>
                                        <td><?= htmlspecialchars($product['CategoryName']) ?></td>
                                    </tr>
                                    <tr>
                                        <th><i class="bi bi-cash-coin"></i> Giá bán</th>
                                        <td class="text-danger fw-bold"><?= number_format($product['Price']) ?> đ</td>
                                    </tr>
                                    <tr>
                                        <th><i class="bi bi-star"></i> Đánh giá</th>
                                        <td><span
                                                class="badge bg-warning text-dark"><?= $product['Rating'] ?>/5.0</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th><i class="bi bi-check-circle"></i> Tình trạng</th>
                                        <td><span class="badge bg-success">Còn hàng</span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-grid gap-2">
                            <button class="btn btn-danger btn-lg">
                                <i class="bi bi-cart-plus"></i> Thêm vào giỏ hàng
                            </button>
                            <button class="btn btn-outline-primary">
                                <i class="bi bi-heart"></i> Yêu thích
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Related Products -->
        <?php if (!empty($relatedProducts)): ?>
            <div class="mt-5">
                <h4 class="mb-4"><i class="bi bi-grid"></i> Sản phẩm liên quan</h4>
                <div class="row">
                    <?php foreach ($relatedProducts as $relatedProduct): ?>
                        <div class="col-md-3 mb-4">
                            <div class="card h-100 shadow-sm">
                                <img src="<?= $relatedProduct['Image'] ? 'uploads/' . $relatedProduct['Image'] : 'https://via.placeholder.com/300x200?text=No+Image' ?>"
                                    class="card-img-top" alt="<?= htmlspecialchars($relatedProduct['ProductName']) ?>"
                                    style="height:180px;object-fit:cover">
                                <div class="card-body">
                                    <h6 class="card-title text-truncate"
                                        title="<?= htmlspecialchars($relatedProduct['ProductName']) ?>">
                                        <?= htmlspecialchars($relatedProduct['ProductName']) ?>
                                    </h6>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-danger fw-bold"><?= number_format($relatedProduct['Price']) ?>đ</span>
                                        <span class="badge bg-warning text-dark">
                                            <i class="bi bi-star-fill"></i> <?= $relatedProduct['Rating'] ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="card-footer bg-white border-top-0">
                                    <a href="product.php?id=<?= $relatedProduct['ProductID'] ?>"
                                        class="btn btn-outline-primary btn-sm w-100">
                                        <i class="bi bi-eye"></i> Xem chi tiết
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Back to Search -->
        <div class="text-center my-4">
            <a href="index.php" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left-circle"></i> Quay lại trang tìm kiếm
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>