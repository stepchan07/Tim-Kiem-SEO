<?php
require_once 'config.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Get user's search history with results
$stmt = $pdo->prepare("
    SELECT 
        sl.SearchID,
        sl.Keyword,
        sl.SearchDate,
        COUNT(sr.ResultID) as ResultCount
    FROM SearchLog sl
    LEFT JOIN SearchResult sr ON sl.SearchID = sr.SearchID
    WHERE sl.UserID = ?
    GROUP BY sl.SearchID
    ORDER BY sl.SearchDate DESC
    LIMIT 50
");
$stmt->execute([$_SESSION['user_id']]);
$searches = $stmt->fetchAll();

// Get search details if clicked
$searchDetails = [];
$selectedSearchID = $_GET['search_id'] ?? null;

if ($selectedSearchID) {
    $stmt = $pdo->prepare("
        SELECT 
            p.*,
            c.CategoryName,
            sr.Rank
        FROM SearchResult sr
        JOIN Product p ON sr.ProductID = p.ProductID
        LEFT JOIN Category c ON p.CategoryID = c.CategoryID
        WHERE sr.SearchID = ?
        ORDER BY sr.Rank ASC
    ");
    $stmt->execute([$selectedSearchID]);
    $searchDetails = $stmt->fetchAll();
}

// Delete history
if (isset($_POST['delete_all'])) {
    $stmt = $pdo->prepare("DELETE FROM SearchLog WHERE UserID = ?");
    $stmt->execute([$_SESSION['user_id']]);
    header('Location: history.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lịch sử tìm kiếm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
</head>

<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-arrow-left"></i> Quay lại
            </a>
            <div class="d-flex align-items-center text-white">
                <span class="me-3">Xin chào, <?= getCurrentUser() ?></span>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4><i class="bi bi-clock-history"></i> Lịch sử tìm kiếm của tôi</h4>
            <?php if (!empty($searches)): ?>
                <form method="POST" onsubmit="return confirm('Bạn có chắc muốn xóa tất cả lịch sử?')">
                    <button type="submit" name="delete_all" class="btn btn-danger btn-sm">
                        <i class="bi bi-trash"></i> Xóa tất cả
                    </button>
                </form>
            <?php endif; ?>
        </div>

        <div class="row">
            <!-- Left: Search history list -->
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <strong>Danh sách tìm kiếm</strong>
                    </div>
                    <div class="list-group list-group-flush" style="max-height: 600px; overflow-y: auto;">
                        <?php if (empty($searches)): ?>
                            <div class="list-group-item text-center text-muted py-4">
                                <i class="bi bi-inbox fs-1"></i>
                                <p class="mt-2 mb-0">Chưa có lịch sử tìm kiếm</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($searches as $search): ?>
                                <a href="?search_id=<?= $search['SearchID'] ?>"
                                    class="list-group-item list-group-item-action <?= $selectedSearchID == $search['SearchID'] ? 'active' : '' ?>">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1">
                                            <i class="bi bi-search"></i> <?= htmlspecialchars($search['Keyword']) ?>
                                        </h6>
                                        <small><?= $search['ResultCount'] ?> kết quả</small>
                                    </div>
                                    <small class="text-muted">
                                        <i class="bi bi-calendar"></i>
                                        <?= date('d/m/Y H:i', strtotime($search['SearchDate'])) ?>
                                    </small>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right: Search results -->
            <div class="col-md-8">
                <?php if ($selectedSearchID && !empty($searchDetails)): ?>
                    <div class="card shadow-sm">
                        <div class="card-header bg-success text-white">
                            <strong>Kết quả tìm kiếm</strong>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <?php foreach ($searchDetails as $product): ?>
                                    <div class="col-md-6 mb-3">
                                        <div class="card h-100">
                                            <div class="position-relative">
                                                <img src="<?= $product['Image'] ? 'uploads/' . $product['Image'] : 'https://via.placeholder.com/300x150?text=No+Image' ?>"
                                                    class="card-img-top" alt="<?= htmlspecialchars($product['ProductName']) ?>"
                                                    style="height:150px;object-fit:cover">
                                                <span class="position-absolute top-0 start-0 badge bg-danger m-2">
                                                    #<?= $product['Rank'] ?>
                                                </span>
                                            </div>
                                            <div class="card-body">
                                                <h6 class="card-title"><?= htmlspecialchars($product['ProductName']) ?></h6>
                                                <p class="text-muted small mb-2">
                                                    <i class="bi bi-tag"></i> <?= htmlspecialchars($product['CategoryName']) ?>
                                                </p>
                                                <p class="text-danger fw-bold mb-1"><?= number_format($product['Price']) ?> đ
                                                </p>
                                                <p class="mb-0">
                                                    <i class="bi bi-star-fill text-warning"></i> <?= $product['Rating'] ?>
                                                </p>
                                                <small
                                                    class="text-muted d-block mt-2"><?= htmlspecialchars($product['Description']) ?></small>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php elseif ($selectedSearchID): ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> Không có kết quả cho tìm kiếm này
                    </div>
                <?php else: ?>
                    <div class="card shadow-sm">
                        <div class="card-body text-center py-5">
                            <i class="bi bi-arrow-left-circle fs-1 text-muted"></i>
                            <p class="mt-3 text-muted">Chọn một lịch sử tìm kiếm bên trái để xem chi tiết</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Statistics -->
        <?php if (!empty($searches)): ?>
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h6 class="card-title"><i class="bi bi-graph-up"></i> Thống kê</h6>
                            <div class="row text-center">
                                <div class="col-md-3">
                                    <div class="border rounded p-3">
                                        <h3 class="text-primary"><?= count($searches) ?></h3>
                                        <small class="text-muted">Lượt tìm kiếm</small>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="border rounded p-3">
                                        <h3 class="text-success"><?= array_sum(array_column($searches, 'ResultCount')) ?>
                                        </h3>
                                        <small class="text-muted">Tổng kết quả</small>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="border rounded p-3">
                                        <h3 class="text-warning">
                                            <?= !empty($searches) ? round(array_sum(array_column($searches, 'ResultCount')) / count($searches), 1) : 0 ?>
                                        </h3>
                                        <small class="text-muted">TB kết quả/lần</small>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="border rounded p-3">
                                        <h3 class="text-info"><?= date('d/m/Y', strtotime($searches[0]['SearchDate'])) ?>
                                        </h3>
                                        <small class="text-muted">Tìm kiếm gần nhất</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>

</html>