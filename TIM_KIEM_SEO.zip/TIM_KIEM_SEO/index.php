<?php
require_once 'config.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$keyword = $_GET['search'] ?? '';
$categoryFilter = $_GET['category'] ?? '';
$sortBy = $_GET['sort'] ?? 'newest';
$priceMin = $_GET['price_min'] ?? '';
$priceMax = $_GET['price_max'] ?? '';
$ratingMin = $_GET['rating'] ?? '';
$products = [];

// Get all categories for filter
$stmt = $pdo->query("SELECT * FROM Category ORDER BY CategoryName");
$categories = $stmt->fetchAll();

// Build search query
$conditions = [];
$params = [];

if ($keyword) {
    $conditions[] = "(p.ProductName LIKE ? OR p.Description LIKE ?)";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
}

if ($categoryFilter) {
    $conditions[] = "p.CategoryID = ?";
    $params[] = $categoryFilter;
}

if ($priceMin !== '') {
    $conditions[] = "p.Price >= ?";
    $params[] = $priceMin;
}

if ($priceMax !== '') {
    $conditions[] = "p.Price <= ?";
    $params[] = $priceMax;
}

if ($ratingMin !== '') {
    $conditions[] = "p.Rating >= ?";
    $params[] = $ratingMin;
}

// Determine sort order
$orderBy = match ($sortBy) {
    'price_asc' => 'p.Price ASC',
    'price_desc' => 'p.Price DESC',
    'rating' => 'p.Rating DESC',
    'name' => 'p.ProductName ASC',
    default => 'p.ProductID DESC'
};

if ($keyword || $categoryFilter || $priceMin || $priceMax || $ratingMin) {
    // Log search
    $searchKeyword = $keyword ?: "Lọc sản phẩm";
    $stmt = $pdo->prepare("INSERT INTO SearchLog (UserID, Keyword) VALUES (?, ?)");
    $stmt->execute([$_SESSION['user_id'], $searchKeyword]);
    $searchID = $pdo->lastInsertId();

    // Search products
    $sql = "SELECT p.*, c.CategoryName FROM Product p 
            LEFT JOIN Category c ON p.CategoryID = c.CategoryID";

    if (!empty($conditions)) {
        $sql .= " WHERE " . implode(" AND ", $conditions);
    }

    $sql .= " ORDER BY " . $orderBy;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll();

    // Log results
    $rank = 1;
    foreach ($products as $product) {
        $stmt = $pdo->prepare("INSERT INTO SearchResult (SearchID, ProductID, Rank) VALUES (?, ?, ?)");
        $stmt->execute([$searchID, $product['ProductID'], $rank++]);
    }
} else {
    // Get all products
    $stmt = $pdo->query("SELECT p.*, c.CategoryName FROM Product p 
                         LEFT JOIN Category c ON p.CategoryID = c.CategoryID 
                         ORDER BY " . $orderBy);
    $products = $stmt->fetchAll();
}

// Get statistics
$totalProducts = count($products);
$avgPrice = $totalProducts > 0 ? array_sum(array_column($products, 'Price')) / $totalProducts : 0;
$avgRating = $totalProducts > 0 ? array_sum(array_column($products, 'Rating')) / $totalProducts : 0;
?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tìm kiếm sản phẩm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        .hover-shadow {
            transition: all 0.3s;
        }

        .hover-shadow:hover {
            transform: translateY(-5px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
        }

        /* Live Search Suggestions */
        .search-wrapper {
            position: relative;
        }

        .search-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #ddd;
            border-radius: 0.375rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
            max-height: 400px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }

        .search-suggestions.show {
            display: block;
        }

        .suggestion-item {
            padding: 0.75rem 1rem;
            cursor: pointer;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: all 0.2s;
        }

        .suggestion-item:hover {
            background-color: #f8f9fa;
        }

        .suggestion-item:last-child {
            border-bottom: none;
        }

        .suggestion-image {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 0.25rem;
        }

        .suggestion-info {
            flex: 1;
        }

        .suggestion-name {
            font-weight: 600;
            color: #212529;
            margin-bottom: 0.25rem;
        }

        .suggestion-category {
            font-size: 0.875rem;
            color: #6c757d;
        }

        .suggestion-price {
            font-weight: 700;
            color: #dc3545;
            white-space: nowrap;
        }

        .no-results {
            padding: 1rem;
            text-align: center;
            color: #6c757d;
        }

        .search-loading {
            padding: 1rem;
            text-align: center;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-shop"></i> Tìm kiếm sản phẩm
            </a>
            <div class="d-flex align-items-center text-white">
                <span class="me-3">Xin chào, <?= getCurrentUser() ?></span>
                <a href="history.php" class="btn btn-light btn-sm me-2">
                    <i class="bi bi-clock-history"></i> Lịch sử
                </a>
                <a href="add_product.php" class="btn btn-light btn-sm me-2">
                    <i class="bi bi-plus-circle"></i> Thêm sản phẩm
                </a>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Search Bar -->
        <div class="row justify-content-center mb-4">
            <div class="col-md-10">
                <form method="GET" id="searchForm">
                    <div class="row g-2">
                        <div class="col-md-6">
                            <div class="search-wrapper">
                                <input type="text" name="search" id="liveSearch" class="form-control form-control-lg"
                                    placeholder="🔍 Tìm kiếm sản phẩm..." value="<?= htmlspecialchars($keyword) ?>"
                                    autocomplete="off">
                                <div id="searchSuggestions" class="search-suggestions"></div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-search"></i> Search
                            </button>
                        </div>
                        <div class="col-md-4">
                            <select name="category" class="form-select form-select-lg">
                                <option value="">📂 Tất cả danh mục</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['CategoryID'] ?>" <?= $categoryFilter == $cat['CategoryID'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cat['CategoryName']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-outline-primary btn-lg w-100" data-bs-toggle="collapse"
                                data-bs-target="#advancedFilter">
                                <i class="bi bi-sliders"></i> Lọc
                            </button>
                        </div>
                    </div>

                    <!-- Advanced Filters -->
                    <div class="collapse mt-3" id="advancedFilter">
                        <div class="card card-body">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="form-label"><i class="bi bi-cash"></i> Giá từ</label>
                                    <input type="number" name="price_min" class="form-control" placeholder="0"
                                        value="<?= htmlspecialchars($priceMin) ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label"><i class="bi bi-cash-stack"></i> Đến</label>
                                    <input type="number" name="price_max" class="form-control" placeholder="999999999"
                                        value="<?= htmlspecialchars($priceMax) ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label"><i class="bi bi-star"></i> Đánh giá tối thiểu</label>
                                    <select name="rating" class="form-select">
                                        <option value="">Tất cả</option>
                                        <option value="4.5" <?= $ratingMin == '4.5' ? 'selected' : '' ?>>⭐ 4.5+
                                        </option>
                                        <option value="4.0" <?= $ratingMin == '4.0' ? 'selected' : '' ?>>⭐ 4.0+
                                        </option>
                                        <option value="3.5" <?= $ratingMin == '3.5' ? 'selected' : '' ?>>⭐ 3.5+
                                        </option>
                                        <option value="3.0" <?= $ratingMin == '3.0' ? 'selected' : '' ?>>⭐ 3.0+
                                        </option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label"><i class="bi bi-sort-down"></i> Sắp xếp</label>
                                    <select name="sort" class="form-select">
                                        <option value="newest" <?= $sortBy == 'newest' ? 'selected' : '' ?>>Mới nhất
                                        </option>
                                        <option value="price_asc" <?= $sortBy == 'price_asc' ? 'selected' : '' ?>>Giá
                                            thấp
                                            → cao</option>
                                        <option value="price_desc" <?= $sortBy == 'price_desc' ? 'selected' : '' ?>>Giá
                                            cao
                                            → thấp</option>
                                        <option value="rating" <?= $sortBy == 'rating' ? 'selected' : '' ?>>Đánh giá
                                            cao
                                        </option>
                                        <option value="name" <?= $sortBy == 'name' ? 'selected' : '' ?>>Tên A-Z
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="mt-3 text-end">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-search"></i> Áp dụng bộ lọc
                                </button>
                                <a href="index.php" class="btn btn-outline-secondary">
                                    <i class="bi bi-x-circle"></i> Xóa tất cả
                                </a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Statistics Bar -->
        <?php if ($keyword || $categoryFilter || $priceMin || $priceMax || $ratingMin): ?>
            <div class="alert alert-info d-flex justify-content-between align-items-center">
                <div>
                    <strong><i class="bi bi-filter-circle"></i> Kết quả lọc:</strong>
                    <?php if ($keyword): ?>
                        <span class="badge bg-primary">"<?= htmlspecialchars($keyword) ?>"</span>
                    <?php endif; ?>
                    <?php if ($categoryFilter): ?>
                        <span class="badge bg-success"><?php
                        $selectedCat = array_filter($categories, fn($c) => $c['CategoryID'] == $categoryFilter);
                        echo htmlspecialchars(reset($selectedCat)['CategoryName']);
                        ?></span>
                    <?php endif; ?>
                    <?php if ($priceMin || $priceMax): ?>
                        <span class="badge bg-warning text-dark">
                            <?= $priceMin ? number_format($priceMin) : '0' ?>đ -
                            <?= $priceMax ? number_format($priceMax) : '∞' ?>đ
                        </span>
                    <?php endif; ?>
                    <?php if ($ratingMin): ?>
                        <span class="badge bg-info">⭐ <?= $ratingMin ?>+</span>
                    <?php endif; ?>
                    <span class="ms-2">(<?= $totalProducts ?> sản phẩm)</span>
                </div>
                <a href="index.php" class="btn btn-sm btn-outline-dark">
                    <i class="bi bi-x-lg"></i>
                </a>
            </div>
        <?php endif; ?>

        <!-- Quick Stats -->
        <?php if ($totalProducts > 0): ?>
            <div class="row mb-3">
                <div class="col-md-4">
                    <div class="card text-center border-primary">
                        <div class="card-body py-2">
                            <small class="text-muted">Tổng sản phẩm</small>
                            <h5 class="mb-0 text-primary"><?= $totalProducts ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center border-success">
                        <div class="card-body py-2">
                            <small class="text-muted">Giá trung bình</small>
                            <h5 class="mb-0 text-success"><?= number_format($avgPrice) ?>đ</h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center border-warning">
                        <div class="card-body py-2">
                            <small class="text-muted">Đánh giá TB</small>
                            <h5 class="mb-0 text-warning">⭐ <?= number_format($avgRating, 1) ?></h5>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="row">
            <?php if (empty($products)): ?>
                <div class="col-12">
                    <div class="alert alert-info">Không tìm thấy sản phẩm nào</div>
                </div>
            <?php else: ?>
                <?php foreach ($products as $product): ?>
                    <div class="col-md-3 mb-4">
                        <div class="card h-100 shadow-sm hover-shadow">
                            <div class="position-relative">
                                <img src="<?= $product['Image'] ? 'uploads/' . $product['Image'] : 'https://via.placeholder.com/300x200?text=No+Image' ?>"
                                    class="card-img-top" alt="<?= htmlspecialchars($product['ProductName']) ?>"
                                    style="height:200px;object-fit:cover">
                                <?php if ($product['Rating'] >= 4.5): ?>
                                    <span class="position-absolute top-0 end-0 badge bg-danger m-2">
                                        <i class="bi bi-fire"></i> Hot
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="card-body">
                                <h6 class="card-title text-truncate" title="<?= htmlspecialchars($product['ProductName']) ?>">
                                    <?= htmlspecialchars($product['ProductName']) ?>
                                </h6>
                                <p class="text-muted small mb-2">
                                    <i class="bi bi-tag-fill"></i> <?= htmlspecialchars($product['CategoryName']) ?>
                                </p>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="text-danger fw-bold"><?= number_format($product['Price']) ?>đ</span>
                                    <span class="badge bg-warning text-dark">
                                        <i class="bi bi-star-fill"></i> <?= $product['Rating'] ?>
                                    </span>
                                </div>
                                <p class="text-muted small mb-0" style="font-size:0.8rem; height:2.4rem; overflow:hidden;">
                                    <?= htmlspecialchars($product['Description']) ?>
                                </p>
                            </div>
                            <div class="card-footer bg-white border-top-0">
                                <a href="product.php?id=<?= $product['ProductID'] ?>" class="btn btn-primary btn-sm w-100">
                                    <i class="bi bi-eye"></i> Xem chi tiết
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>