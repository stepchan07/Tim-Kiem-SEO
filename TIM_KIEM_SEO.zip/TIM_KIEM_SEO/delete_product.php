<?php
require_once 'config.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$productID = $_GET['id'] ?? 0;

// Kiểm tra sản phẩm tồn tại
$stmt = $pdo->prepare("SELECT * FROM Product WHERE ProductID = ?");
$stmt->execute([$productID]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: index.php');
    exit;
}

// Xóa sản phẩm
$stmt = $pdo->prepare("DELETE FROM Product WHERE ProductID = ?");
$stmt->execute([$productID]);

// Redirect về trang danh sách hoặc trang chủ
header('Location: index.php?msg=deleted');
exit;
?>