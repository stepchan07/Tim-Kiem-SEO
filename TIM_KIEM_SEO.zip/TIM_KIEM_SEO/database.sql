CREATE DATABASE IF NOT EXISTS product_search;
USE product_search;

CREATE TABLE Category (
    CategoryID INT PRIMARY KEY AUTO_INCREMENT,
    CategoryName VARCHAR(255) NOT NULL
);

CREATE TABLE User (
    UserID INT PRIMARY KEY AUTO_INCREMENT,
    UserName VARCHAR(255) NOT NULL,
    Email VARCHAR(255) UNIQUE NOT NULL,
    Password VARCHAR(255) NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Product (
    ProductID INT PRIMARY KEY AUTO_INCREMENT,
    ProductName VARCHAR(255) NOT NULL,
    CategoryID INT,
    Price DECIMAL(10,2),
    Rating DECIMAL(2,1),
    Image VARCHAR(255),
    Description TEXT,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);

CREATE TABLE SearchLog (
    SearchID INT PRIMARY KEY AUTO_INCREMENT,
    UserID INT,
    Keyword VARCHAR(255),
    SearchDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES User(UserID)
);

CREATE TABLE SearchResult (
    ResultID INT PRIMARY KEY AUTO_INCREMENT,
    SearchID INT,
    ProductID INT,
    Rank INT,
    FOREIGN KEY (SearchID) REFERENCES SearchLog(SearchID),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);

-- Sample data
INSERT INTO Category (CategoryName) VALUES 
('Điện thoại'), ('Laptop'), ('Phụ kiện'), ('Tablet');

INSERT INTO User (UserName, Email, Password) VALUES 
('admin', 'admin@example.com', MD5('admin123'));

INSERT INTO Product (ProductName, CategoryID, Price, Rating, Image, Description) VALUES
('iPhone 15 Pro', 1, 29990000, 4.8, 'iphone15.jpg', 'iPhone 15 Pro mới nhất'),
('Samsung Galaxy S24', 1, 24990000, 4.7, 'samsung-s24.jpg', 'Samsung Galaxy S24 flagship'),
('MacBook Pro M3', 2, 45990000, 4.9, 'macbook-m3.jpg', 'MacBook Pro chip M3'),
('Dell XPS 15', 2, 35990000, 4.6, 'dell-xps.jpg', 'Dell XPS 15 cao cấp');