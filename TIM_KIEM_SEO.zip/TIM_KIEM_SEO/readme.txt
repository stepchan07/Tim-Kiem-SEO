README – HỆ THỐNG TÌM KIẾM SẢN PHẨM SEO
---------------------------------------

1. GIỚI THIỆU
Hệ thống Tìm kiếm Sản phẩm SEO (PHP + MySQL + Bootstrap) cho phép:
- Quản lý người dùng (Đăng ký / Đăng nhập)
- Quản lý sản phẩm, danh mục
- Tìm kiếm sản phẩm thông minh theo từ khóa, danh mục, giá, đánh giá
- Ghi log tìm kiếm và kết quả để phân tích SEO
- Xem chi tiết sản phẩm, sản phẩm liên quan

---------------------------------------
2. YÊU CẦU CHẠY DỰ ÁN
---------------------------------------
- XAMPP hoặc WAMP (khuyến nghị XAMPP)
- PHP 7.4 trở lên
- MySQL 5.7+
- Trình duyệt bất kỳ (Chrome/Edge/Firefox)

---------------------------------------
3. HƯỚNG DẪN CÀI ĐẶT
---------------------------------------

Bước 1 — Tải mã nguồn
---------------------
- Copy toàn bộ project vào thư mục:
  C:\xampp\htdocs\TIM_KIEM_SEO

Bước 2 — Tạo database
---------------------
- Mở phpMyAdmin: http://localhost/phpmyadmin
- Tạo database mới với tên:
  **product_search**

- Import file database:
  db.sql (đã cung cấp trong project)

Bước 3 — Kiểm tra file config.php
----------------------------------
Mở file: config.php  
Đảm bảo thông tin kết nối MySQL:

$host = "localhost";
$dbname = "product_search";
$username = "root";
$password = "";

Nếu bạn dùng XAMPP → giữ nguyên.

---------------------------------------
4. CHẠY DỰ ÁN
---------------------------------------
Mở trình duyệt và chạy URL:

http://localhost/TIM_KIEM_SEO/

Nếu database + config đúng → trang login sẽ hiển thị.

---------------------------------------
5. TÀI KHOẢN TEST ĐĂNG NHẬP
---------------------------------------
Email: **khamchanh048@gmail.con**  
Password: **123456**

---------------------------------------
6. CHỨC NĂNG CHÍNH
---------------------------------------
✓ Đăng ký / Đăng nhập  
✓ Quản lý sản phẩm (thêm / sửa / xóa)  
✓ Quản lý danh mục  
✓ Tìm kiếm theo từ khóa  
✓ Tìm kiếm theo danh mục  
✓ Xem chi tiết sản phẩm  
✓ Ghi log SearchLog + SearchResult  
✓ Thống kê kết quả tìm kiếm  
✓ Hiển thị sản phẩm liên quan  

---------------------------------------
7. CÁCH XÓA SẢN PHẨM KHÔNG LỖI FOREIGN KEY
---------------------------------------
Nếu sản phẩm đã từng xuất hiện trong SearchResult thì không thể xóa trực tiếp.

Có 2 cách sửa lỗi:

Cách 1 — Xóa log trước:
DELETE FROM SearchResult WHERE ProductID = X;
DELETE FROM SearchLog WHERE SearchID NOT IN (SELECT SearchID FROM SearchResult);

Cách 2 — Thêm ON DELETE CASCADE trong database (khuyến nghị).

---------------------------------------
8. LỖI THƯỜNG GẶP
---------------------------------------

❌ Lỗi 500 → config.php sai  
❌ Không login được → database chưa import  
❌ Lỗi xóa sản phẩm → thiếu ON DELETE CASCADE  

---------------------------------------
9. LIÊN HỆ
---------------------------------------
Email hỗ trợ: khamchanh048@gmail.con
